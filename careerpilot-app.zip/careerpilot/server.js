// CareerPilot AI: tiny zero-dependency server. Keeps your API key on the server.
const http = require("http"), fs = require("fs"), path = require("path");
try { fs.readFileSync(path.join(__dirname, ".env"), "utf8").split("\n").forEach(l => {
  const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }); } catch (e) {}
const KEY = process.env.ANTHROPIC_API_KEY, MODEL = process.env.MODEL || "claude-sonnet-5-5";
const SEARCH = process.env.ENABLE_SEARCH === "true", PORT = process.env.PORT || 3000;
if (!KEY) { console.error("Missing ANTHROPIC_API_KEY. Copy .env.example to .env and add your key."); process.exit(1); }

const SYSTEM = `You are CareerPilot AI, a warm, practical career advisor in a chat. Rules:
- Talk like a friendly mentor. Keep replies short (under about 150 words unless asked for a plan or detailed review).
- Never make the person fill a questionnaire. Ask at most ONE short question per reply, only when it moves things forward. Remember everything they tell you (studies, skills, interests, goals, location, experience) and never re-ask it.
- Learn their profile gradually: studies, skills, target roles, experience level, preferred locations, remote/hybrid/on-site, goals.
- You can suggest career paths and compare them objectively, find and prioritize skill gaps, recommend free/official learning resources and projects, build roadmaps (30 days, 3, 6, 12 months), review resumes or job descriptions pasted in chat, write cover letters, and run mock interviews.
- Never invent job openings, companies, deadlines, salaries, or application links. Never invent experience for the user. Never guarantee jobs or acceptance.
- Opportunity match scores are your estimate from their profile, not an official score. Label opinion versus fact.
${SEARCH
 ? "- You have a web search tool. For openings, internships, scholarships, hackathons or deadlines, search, prefer official sources, and give title, organization, location, deadline (or 'Not specified'), and the link. Skip anything whose deadline has passed. Show the top 3 to 5 matches, not a flood."
 : "- You cannot search the web or see live listings. When asked for opportunities, say so, name the types of opportunities and official sources to check, and offer to score any posting they paste in."}
- Finish important answers with one clear next step. Plain language, short bullets only when helpful, no headings.`;

const hits = new Map(); // simple per-IP rate limit: 20 requests / minute
function limited(ip) { const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 6e4); a.push(now); hits.set(ip, a); return a.length > 20; }

async function chat(history) {
  let msgs = history.filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string" && m.content.trim())
    .slice(-30).map(m => ({ role: m.role, content: m.content.slice(0, 8000) }));
  while (msgs.length && msgs[0].role !== "user") msgs.shift();   // API needs the first message to be from the user
  if (!msgs.length) throw new Error("No message");
  const body = { model: MODEL, max_tokens: 1200, system: SYSTEM, messages: msgs };
  if (SEARCH) body.tools = [{ type: "web_search_20250305", name: "web_search", max_uses: 5 }];
  const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST",
    headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" }, body: JSON.stringify(body) });
  const j = await r.json();
  if (!r.ok) throw new Error((j.error && j.error.message) || "API error " + r.status);
  return j.content.filter(b => b.type === "text").map(b => b.text).join("");
}

http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/api/chat") {
    if (limited(req.socket.remoteAddress)) { res.writeHead(429); return res.end(JSON.stringify({ error: "Too many requests" })); }
    let data = ""; req.on("data", c => { data += c; if (data.length > 2e5) req.destroy(); });
    req.on("end", async () => {
      try { const text = await chat(JSON.parse(data).messages || []);
        res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify({ text }));
      } catch (e) { console.error(e.message); res.writeHead(500, { "content-type": "application/json" }); res.end(JSON.stringify({ error: "Something went wrong." })); }
    });
  } else {
    fs.readFile(path.join(__dirname, "public", "index.html"), (e, d) => { res.writeHead(e ? 404 : 200, { "content-type": "text/html; charset=utf-8" }); res.end(d); });
  }
}).listen(PORT, () => console.log("CareerPilot running at http://localhost:" + PORT));
