# CareerPilot AI (your own copy)

1. Install Node.js 18 or newer (https://nodejs.org).
2. Get an API key at https://console.anthropic.com and add some credit.
3. In this folder: copy `.env.example` to `.env` and paste your key.
4. Run `node server.js` and open http://localhost:3000

Optional: set `ENABLE_SEARCH=true` in `.env` to let the bot search the web for current opportunities (turn on web search in your Console first).

To put it online, deploy this folder to any Node host (Render, Railway, Fly.io, a VPS). Set the same variables there. Never put your API key in `index.html`.
